# CMPE-202

# Java UML Parser

Technology stack -
Java

Java Code Parsing Library - 
JavaParser

UML Diagram Generation Library - 
PlantUML

# Run UML Parser
>> java -jar umlparser.jar ./test5 output.png

# You Tube Demo link
https://www.youtube.com/watch?v=7l1KRk-BFBg


