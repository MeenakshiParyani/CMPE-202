/**
 * 
 */

/**
 * @author Meenakshi
 *
 */
public class TheEconomy extends ConcreteSubject {

    public TheEconomy()
    {
        super.setState("The Price of gas is at $5.00/gal");
    }
	 
}
