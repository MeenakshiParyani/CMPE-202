/**
 * 
 */

/**
 * @author Meenakshi
 *
 */
public interface Observer {
 
	public abstract void update();
}