/**
 * @author Meenakshi
 *
 */
public interface PriceDecorator
{
	Double getPrice();
}
