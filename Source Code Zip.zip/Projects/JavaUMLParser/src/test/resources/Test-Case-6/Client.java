/**
 * @author Meenakshi
 *
 */
public class Client {
	public static void main(String[] args)
	{
		Component theOrder = BuildOrder.getOrder() ;
		theOrder.printDescription();
	}
}