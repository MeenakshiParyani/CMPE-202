/**
 * 
 */

/**
 * @author Meenakshi
 *
 */
public class C1 {

	public void test( A1 a1 ) {
        // call a1 methods
    }
}
