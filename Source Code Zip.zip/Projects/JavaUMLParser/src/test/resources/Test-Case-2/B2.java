/**
 * 
 */

/**
 * @author Meenakshi
 *
 */
public class B2 extends P implements A1, A2 {

}
