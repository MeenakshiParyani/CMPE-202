/**
 * 
 */
package com.sjsu.uml;

/**
 * @author Meenakshi
 *
 */
public interface Relationship {
	
	public String getSymbol();
	public String getLabel();

}
